# SABER-PID RINENG V10 submission package

`paper/manuscript.tex` and `paper/supplementary.tex` are the editable sources. Only the nine active V10 PDF figures and six referenced TeX tables are included. Editorial files and final reference PDFs are provided separately in their original paths.
