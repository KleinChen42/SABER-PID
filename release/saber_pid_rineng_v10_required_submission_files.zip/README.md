# Results in Engineering upload set

Required files are stored at the archive root using upload-ready names. The manuscript and supplementary PDFs have matching, complete editable LaTeX sources in `Editable_LaTeX_Source.zip`. No Data in Brief or MethodsX co-submission is included because no co-submission was selected. Data and code are linked through https://github.com/KleinChen42/SABER-PID.
